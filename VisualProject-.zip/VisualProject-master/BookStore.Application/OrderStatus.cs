﻿namespace BookStore.Application
{
    public enum OrderStatus
    {
        Placed,
        Confirm,
        Shipped,
        Delivered,
        Canceled,
        Return
    }
}
