﻿using BookStore.Models;

namespace BookStore.Application.Contracts
{
    public interface  IBookCategoryRepository: IRepository<BookCategory,int>
  {

  }
}
